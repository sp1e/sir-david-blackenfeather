sp1e local agents

1. Install Python 3.10+ and sign in to Claude Code or Codex.
2. Windows: double-click Start-agent.cmd. macOS/Linux: run sh start-agent.sh.
3. Open the website, choose your agent and click Connect. Approve in the local
   window. The connection lasts one hour and can be disconnected from the site.
4. Or open http://127.0.0.1:4318/gadgets/ for the local workshop.

The companion binds only to 127.0.0.1:4318. No API key is required here; the
installed CLI owns authentication. Provider tokens are never copied by this
companion. Requests consume your normal provider quota. Native CLI tools and MCP
are disabled. Sir David can use the scoped text-file broker described below.
Prompts and current gadget code go to the selected provider via its official CLI.
Private gadget data is kept in your browser. Stop the terminal to disconnect all
sessions. If the design workspace is running, use its existing companion.

Codex can use your existing ChatGPT sign-in. Sign in through the official CLI;
you do not need to create an OpenAI API key for this connection.

Sir David file tools (Windows only)

Choose a separate folder for Sir David, containing only files you want it to use.
Do not select your home folder or the website's source folder. Configure it locally:
python configure_workspace.py --root "C:\Sir-David-Workspace"
Restart the companion, then connect Claude from Sir David in Admin on sp1e.se.
In the local connection window, check the separate file-access box and approve.
The box starts unchecked. Existing connections and preview sites have no file access.
In Admin, check "Arbeta med filer i min arbetsmapp" for a file task. Uncheck it
to return to chat. Disconnect the companion session to revoke that session's scope.
You can disable file access locally with: python configure_workspace.py --disable

Sir David can list, read and search UTF-8 text files, and make revision-checked edits
inside the chosen folder. File content needed for a task goes to Claude using your
existing sign-in. File history and backups stay in private/file-history beside the
companion. Use Filhistorik in Admin to restore a change; a later external edit can
prevent restoration. An interrupted task may have already changed a file.
Local configuration, file history and your workspace files are not included in this ZIP.
Source: https://github.com/sp1e/sp1e.se
