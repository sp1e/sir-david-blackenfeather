sp1e local agents

1. Install Python 3.10+ and sign in to Claude Code or Codex.
2. Windows: double-click Start-agent.cmd. macOS/Linux: run sh start-agent.sh.
3. Open the website, choose your agent and click Connect. Approve in the local
   window. The connection lasts one hour and can be disconnected from the site.
4. Or open http://127.0.0.1:4318/gadgets/ for the local workshop.

The companion binds only to 127.0.0.1:4318. No API key is required here; the
installed CLI owns authentication. Provider tokens are never copied by this
companion. Requests consume your normal provider quota. Agent tools are disabled.
Prompts and current gadget code go to the selected provider via its official CLI.
Private gadget data is kept in your browser. Stop the terminal to disconnect all
sessions. If the design workspace is running, use its existing companion.

Codex can use your existing ChatGPT sign-in. Sign in through the official CLI;
you do not need to create an OpenAI API key for this connection.
Source: https://github.com/sp1e/sp1e.se
