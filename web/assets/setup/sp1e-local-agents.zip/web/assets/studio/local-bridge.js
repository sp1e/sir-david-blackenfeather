/* The bearer here is a short-lived bridge grant, never a provider credential. */
(() => {
  const local=['localhost','127.0.0.1'].includes(location.hostname);
  const base=local?'':'http://127.0.0.1:4318';
  let token='',pairing=null,catalogLoaded=false;
  const catalogs={codex:[],claude:[]},selections={codex:{model:'',effort:''},claude:{model:'',effort:''}};
  const choices=new Set();
  for(const id of ['codex','claude']){try{const saved=JSON.parse(localStorage.getItem('sp1e-'+id+'-options')||'null');if(saved&&typeof saved.model==='string'&&typeof saved.effort==='string')selections[id]={model:saved.model,effort:saved.effort};}catch{}}
  const saveChoices=id=>{try{localStorage.setItem('sp1e-'+id+'-options',JSON.stringify(selections[id]));}catch{}};
  function refreshCatalog(data){catalogLoaded=true;for(const id of ['codex','claude'])catalogs[id]=data.providers?.find(provider=>provider.id===id)?.models||[];for(const choice of choices)choice.refresh();return data;}
  function mountChoices(id,{provider,model,effort,note}){
    if(!provider||!model||!effort)return null;
    let busy=false;
    function refresh(){
      const visible=provider.value===id;
      model.closest('label').hidden=!visible;effort.closest('label').hidden=!visible;if(note)note.hidden=!visible;
      const catalog=catalogs[id],selection=selections[id];
      const valid=catalog.find(item=>item.id===selection.model);
      if(catalogLoaded&&!valid){selection.model='';selection.effort='';}
      model.replaceChildren(new Option((id==='claude'?'Claude':'Codex')+' standard',''),...catalog.map(item=>new Option(item.name,item.id)));
      model.value=valid?selection.model:'';
      const levels=valid?.efforts||[];if(catalogLoaded&&!levels.includes(selection.effort))selection.effort='';
      if(id==='claude'&&valid&&!levels.length)effort.closest('label').hidden=true;
      const names={none:'None',minimal:'Minimal',low:'Low',medium:'Medium',high:'High',xhigh:'Extra high',max:'Max',ultra:'Ultra'};
      effort.replaceChildren(new Option('Modellens standard',''),...levels.map(value=>new Option(names[value]||value,value)));
      effort.value=selection.effort;model.disabled=busy;effort.disabled=busy||!levels.length;
      if(note)note.textContent=selection.model==='fable'?'Fable kan använda extra krediter.':catalog.length?'Högre effort kan ta längre tid och använda mer av din kvot.':catalogLoaded?'Modellistan saknas. Agentens standard kan fortfarande användas.':'Anslut agenten för att läsa modellistan från din dator.';
    }
    model.addEventListener('change',()=>{if(busy)return;selections[id].model=model.value;refresh();saveChoices(id);});
    effort.addEventListener('change',()=>{if(busy)return;selections[id].effort=effort.value;saveChoices(id);});
    provider.addEventListener('change',refresh);
    const choice={refresh,setBusy(value){busy=value;refresh();}};choices.add(choice);refresh();return choice;
  }
  const mountCodexChoices=options=>mountChoices('codex',options);
  const mountClaudeChoices=options=>mountChoices('claude',options);
  try{token=sessionStorage.getItem('sp1e-agent-session')||'';}catch{}
  const remember=value=>{token=value;try{if(value)sessionStorage.setItem('sp1e-agent-session',value);else sessionStorage.removeItem('sp1e-agent-session');}catch{}};
  async function request(path,body,signal){
    let response;
    try{response=await fetch(base+'/__agents/'+path,{method:body===undefined?'GET':'POST',headers:{...(body!==undefined?{'Content-Type':'application/json'}:{}),...(token?{'X-Sp1e-Session':token}:{})},body:body===undefined?undefined:JSON.stringify(body),signal:signal||AbortSignal.timeout(25000)});}
    catch(problem){if(problem.name==='AbortError')throw problem;const error=Error('Starta den lokala sp1e-agenten och tillåt webbläsarens anslutning till din dator. Du kan även öppna verkstaden på localhost.');error.code='bridge_unavailable';throw error;}
    const data=await response.json().catch(()=>({}));
    if(!response.ok){if(response.status===401)remember('');const error=Error(response.status===401?'Anslutningen har gått ut eller agenten har startats om. Välj Anslut igen.':data.error||'Anslutningen kunde inte användas. Försök igen.');error.code=response.status===401?'bridge_session_expired':'bridge_request_failed';throw error;}
    return data;
  }
  function pair(){
    if(local)return request('session',{origin:location.origin}).then(data=>remember(data.token));
    if(pairing)return pairing;
    const popup=window.open(base+'/__connect/?origin='+encodeURIComponent(location.origin),'sp1e-connect','popup,width=540,height=660');
    if(!popup)return Promise.reject(Error('Tillåt anslutningsfönstret och välj Anslut igen.'));
    pairing=new Promise((resolve,reject)=>{
      let ended=false;
      const finish=problem=>{if(ended)return;ended=true;clearTimeout(timeout);clearInterval(closed);window.removeEventListener('message',receive);pairing=null;if(problem)reject(problem);else resolve();};
      const receive=event=>{if(event.origin!=='http://127.0.0.1:4318'||event.source!==popup||event.data?.type!=='sp1e-local-paired'||typeof event.data.token!=='string')return;remember(event.data.token);finish();};
      window.addEventListener('message',receive);
      const timeout=setTimeout(()=>finish(Error('Anslutningen tog för lång tid. Välj Anslut igen.')),120000);
      const closed=setInterval(()=>{if(popup.closed)finish(Error('Anslutningen avbröts. Välj Anslut igen.'));},700);
    });
    return pairing;
  }
  async function connect(){
    if(!token)await pair();
    try{return refreshCatalog(await request('status'));}
    catch(problem){
      // Local pages can renew immediately. Hosted pages need a fresh user click
      // to open the approval window; never reopen it after an awaited fetch.
      if(local&&problem.code==='bridge_session_expired'){await pair();return refreshCatalog(await request('status'));}
      throw problem;
    }
  }
  async function run(body,{signal,onProgress}={}){
    if(!token){const error=Error('Anslut agenten först.');error.code='bridge_session_expired';throw error;}
    let id;
    const cancel=()=>{if(id)request('cancel',{id}).catch(()=>{});};
    signal?.addEventListener('abort',cancel,{once:true});
    try{
      if(signal?.aborted)throw new DOMException('Stoppat','AbortError');
      const selection=selections[body.provider];
      const payload=selection&&(body.provider==='codex'||selection.model||selection.effort)?{...body,...selection}:body;
      const job=await request('jobs',payload);id=job.id;
      if(signal?.aborted){cancel();throw new DOMException('Stoppat','AbortError');}
      while(true){
        const item=await request('jobs/'+id,undefined,signal);
        if(item.state==='done')return item.result;
        if(item.state==='error')throw Error(item.error);
        if(item.state==='cancelled')throw new DOMException('Stoppat','AbortError');
        onProgress?.('Agenten arbetar…');
        await new Promise((resolve,reject)=>{const abort=()=>{clearTimeout(timer);reject(new DOMException('Stoppat','AbortError'));};const timer=setTimeout(()=>{signal?.removeEventListener('abort',abort);resolve();},1000);signal?.addEventListener('abort',abort,{once:true});});
      }
    }finally{signal?.removeEventListener('abort',cancel);}
  }
  async function disconnect(){try{if(token)await request('disconnect',{});}finally{remember('');}}
  window.Sp1eBridge={connect,run,disconnect,mountCodexChoices,mountClaudeChoices,status:async()=>refreshCatalog(await request('status')),isPaired:()=>!!token};
})();
