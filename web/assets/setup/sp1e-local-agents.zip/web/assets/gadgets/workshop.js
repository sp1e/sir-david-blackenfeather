import {sandboxHtml,validArtifact} from './sandbox.js';
import {templates} from './templates.js';
import {allGadgets,saveGadget,deleteGadget} from './storage.js';
const $=id=>document.getElementById(id),bridge=window.Sp1eBridge;
let items=[],current=null,dirty=false,controller=null,connected=false,previewChannel='',saving=false;
let cloudAvailable=false;
async function cloudStatus(){
  const response=await fetch('/api/assistant/status',{credentials:'same-origin'});
  const data=await response.json();if(!response.ok||!data.connected)throw Error('Ollama Cloud kräver en Admin- eller Clique-inloggning.');
  cloudAvailable=true;const option=$('provider').querySelector('option[value="cloud"]');if(option){option.hidden=false;option.disabled=false;}
  const model=$('cloud-model');let previous=model?.value;
  try{previous=previous||localStorage.getItem('sp1e-cloud-model');}catch{}
  if(model){model.replaceChildren(...data.models.map(id=>new Option(data.model_labels?.[id]||id,id)));model.value=data.models.includes(previous)?previous:data.default_model;}
  return data;
}
async function cloudBuild(request,signal){
  const response=await fetch('/api/assistant/gadget',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({model:$('cloud-model').value,messages:[{role:'user',content:request.prompt}],current:request.current}),signal});
  const data=await response.json();if(signal.aborted)throw new DOMException('Stoppat','AbortError');if(!response.ok){if([401,403].includes(response.status)){cloudAvailable=false;connected=false;}throw Error(data.error||'Gadgeten kunde inte byggas.');}return data;
}
const error=message=>{$('error').textContent=message;$('error').hidden=!message;};
const codexChoices=bridge?.mountCodexChoices?.({provider:$('provider'),model:$('codex-model'),effort:$('codex-effort'),note:$('codex-note')});
const claudeChoices=bridge?.mountClaudeChoices?.({provider:$('provider'),model:$('claude-model'),effort:$('claude-effort'),note:$('claude-note')});
function controls(){
  codexChoices?.setBusy(!!controller);
  claudeChoices?.setBusy(!!controller);
  if($('cloud-settings'))$('cloud-settings').hidden=$('provider').value!=='cloud'||!cloudAvailable;
  if($('cloud-model'))$('cloud-model').disabled=!!controller;
  $('build').disabled=!connected||!!controller||!$('build-prompt').value.trim();
  for(const id of ['save','export','delete','versions','git-stage'])$(id).disabled=!current||!!controller||saving;
  $('new').disabled=!!controller||saving;$('provider').disabled=!!controller;$('connect').disabled=!!controller;
  $('code').readOnly=!!controller||saving;$('import').disabled=!!controller||saving;
}
function library(){
  $('library-list').replaceChildren(...items.sort((a,b)=>b.updated-a.updated).map(item=>{const button=document.createElement('button');button.className='library-item'+(current?.id===item.id?' active':'');const title=document.createElement('strong'),date=document.createElement('small');title.textContent=item.title;date.textContent=new Date(item.updated).toLocaleDateString('sv-SE');button.append(title,date);button.onclick=()=>select(item);button.disabled=!!controller;return button;}));
}
function tabs(code){$('code').hidden=!code;$('gadget-preview').hidden=code||!current;$('empty').hidden=!!current;$('run-code').hidden=!code;$('preview-tab').setAttribute('aria-pressed',String(!code));$('code-tab').setAttribute('aria-pressed',String(code));}
function clearPreview(){const old=$('gadget-preview'),frame=old.cloneNode(false);frame.removeAttribute('srcdoc');frame.removeAttribute('src');old.replaceWith(frame);return frame;}
function preview(){
  if(!current)return;
  error('');
  // A fresh opaque frame also discards the previous gadget's document policy.
  const frame=clearPreview();
  previewChannel=crypto.randomUUID();frame.srcdoc=sandboxHtml(current.html,previewChannel);
}
function state(){
  $('gadget-title').textContent=current?.title||'Vad vill du bygga?';$('gadget-summary').textContent=current?.summary||'Beskriv ett verktyg du vill använda, eller börja med en mall.';
  $('code').value=current?.html||'';$('starters').hidden=!!current;
  $('save-status').textContent=current?(dirty?'Osparade ändringar':`Sparad ${new Date(current.updated).toLocaleTimeString('sv-SE',{hour:'2-digit',minute:'2-digit'})}`):'Ingen gadget vald';
  const versions=current?.versions||[];$('versions').replaceChildren(...versions.map((version,i)=>new Option(`${i+1} · ${new Date(version.at).toLocaleTimeString('sv-SE',{hour:'2-digit',minute:'2-digit'})}`,String(i))));
  if(!versions.length)$('versions').add(new Option('Utkast',''));else $('versions').value=String(versions.length-1);
  controls();library();preview();tabs(false);
}
function mayLeave(){return !dirty||confirm('Lämna osparade ändringar? Spara eller exportera först om du vill behålla dem.');}
function select(item){if(controller||saving||!mayLeave())return;current=structuredClone(item);dirty=false;error('');state();}
function create(artifact){if(controller||saving||!mayLeave())return false;current={...validArtifact(artifact),id:crypto.randomUUID(),data:null,versions:[],updated:Date.now()};dirty=true;error('');state();return true;}
$('new').onclick=()=>{if(!mayLeave())return;current=null;dirty=false;error('');clearPreview();state();};
document.querySelectorAll('[data-template]').forEach(button=>{button.onclick=()=>create(templates[button.dataset.template]);});
$('build-prompt').oninput=controls;
$('preview-tab').onclick=()=>tabs(false);$('code-tab').onclick=()=>tabs(true);
$('code').oninput=()=>{if(!current)return;current.html=$('code').value;dirty=true;$('save-status').textContent='Osparade ändringar';};
$('run-code').onclick=()=>{try{validArtifact(current);preview();tabs(false);error('');}catch(problem){error(problem.message);}};
$('versions').onchange=()=>{const version=current?.versions[Number($('versions').value)];if(!version)return;current.html=version.html;dirty=true;$('code').value=current.html;preview();$('save-status').textContent='Tidigare version · spara för att behålla ändringen';};
async function save(){
  if(!current||saving)return;
  try{
    saving=true;controls();validArtifact(current);
    if(!items.some(item=>item.id===current.id)&&items.length>=40)throw Error('Biblioteket rymmer 40 gadgets. Exportera och ta bort en för att spara fler.');
    const snapshot=structuredClone(current);snapshot.updated=Date.now();
    if(snapshot.versions.at(-1)?.html!==snapshot.html)snapshot.versions=[...snapshot.versions,{html:snapshot.html,at:snapshot.updated}].slice(-5);
    await saveGadget(snapshot);current=snapshot;items=items.filter(item=>item.id!==snapshot.id).concat(structuredClone(snapshot));dirty=false;state();
  }catch(problem){error(problem.message);}finally{saving=false;controls();}
}
$('save').onclick=save;
$('export').onclick=()=>{if(!current)return;const data={format:'sp1e-gadget',version:1,...validArtifact(current),data:current.data};const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));const link=document.createElement('a');link.href=url;link.download=(current.title.replace(/[^a-z0-9åäö_-]/gi,'-').slice(0,60)||'gadget')+'.gadget.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
$('delete').onclick=async()=>{if(!current||!confirm('Ta bort den här gadgeten och dess sparade data? Exportera först om du vill behålla en kopia.'))return;try{await deleteGadget(current.id);items=items.filter(item=>item.id!==current.id);current=null;dirty=false;clearPreview();state();}catch(problem){error(problem.message);}};
$('import').onclick=()=>$('import-file').click();
$('import-file').onchange=async event=>{const file=event.target.files?.[0];if(!file)return;try{if(file.size>400000)throw Error('Importfilen är för stor.');const text=await file.text(),artifact=file.name.endsWith('.html')?{title:file.name.replace(/\.html$/i,''),html:text}:JSON.parse(text);const created=create(artifact);if(created&&artifact.data!==undefined&&JSON.stringify(artifact.data).length<=50000){current.data=artifact.data;preview();}}catch(problem){error(problem instanceof SyntaxError?'Filen innehåller ingen giltig gadget.':problem.message);}finally{event.target.value='';}};
window.addEventListener('message',async event=>{
  const message=event.data;if(!current||event.source!==$('gadget-preview').contentWindow||message?.channel!==previewChannel)return;
  if(message.type==='sp1e-gadget-load')event.source.postMessage({type:'sp1e-gadget-state',channel:previewChannel,value:current.data},'*');
  if(message.type==='sp1e-gadget-save'){
    try{const serialized=JSON.stringify(message.value);if(!serialized||serialized.length>50000)throw Error('Gadgetens data är för stora för att sparas.');current.data=JSON.parse(serialized);const saved=items.find(item=>item.id===current.id);if(saved){const snapshot=structuredClone(saved);snapshot.data=current.data;await saveGadget(snapshot);saved.data=snapshot.data;$('save-status').textContent=dirty?'Data sparade · kodändringar osparade':'Gadgetens data har sparats';}else $('save-status').textContent='Spara gadgeten för att behålla dess data';}catch(problem){error(problem.message);}
  }
  if(message.type==='sp1e-gadget-error')error('Gadgetens kod gav ett fel. Öppna Kod eller be agenten rätta det.');
  if(message.type==='sp1e-gadget-blocked')error('Gadgeten försökte använda en blockerad resurs. Be agenten bädda in den direkt i koden.');
});
async function connect(){
  $('connect').disabled=true;error('');$('connection-status').textContent='Kontrollerar din lokala agent…';
  try{
    if($('provider').value==='cloud'){await cloudStatus();connected=true;$('connection-status').textContent='Ollama Cloud är anslutet';}
    else{const data=await bridge.connect(),provider=data.providers.find(p=>p.id===$('provider').value);if(!provider?.installed)throw Error('Agenten är inte installerad. Öppna Anslut din agent för hjälp.');if(!provider.signedIn)throw Error('Logga in i agentens app och välj Anslut igen.');connected=true;$('connection-status').textContent=provider.name+' är ansluten på din dator';}
    $('connect').hidden=true;$('disconnect').hidden=false;
  }
  catch(problem){connected=false;$('connect').hidden=false;error(problem.message);$('connection-status').textContent='Ingen agent ansluten';}finally{$('connect').disabled=false;controls();}
}
$('connect').onclick=connect;
$('provider').onchange=()=>{connected=false;$('connect').hidden=false;$('connection-status').textContent='Välj Anslut för den här agenten';controls();};
$('cloud-model')?.addEventListener('change',()=>{if(controller)return;try{localStorage.setItem('sp1e-cloud-model',$('cloud-model').value);}catch{}});
$('disconnect').onclick=async()=>{controller?.abort();if($('provider').value!=='cloud')await bridge.disconnect().catch(()=>{});connected=false;$('connect').hidden=false;$('disconnect').hidden=true;$('connection-status').textContent='Agenten är frånkopplad';controls();};
$('stop').onclick=()=>controller?.abort();
$('build-form').onsubmit=async event=>{
  event.preventDefault();if(controller||!connected||!$('build-prompt').value.trim())return;
  const request={provider:$('provider').value,kind:'gadget',prompt:$('build-prompt').value.trim(),current:current?.html||''};
  controller=new AbortController();error('');$('stop').hidden=false;$('build').hidden=true;controls();library();
  try{const result=validArtifact(await (request.provider==='cloud'?cloudBuild(request,controller.signal):bridge.run(request,{signal:controller.signal,onProgress:message=>{$('connection-status').textContent=message;}})));
    if(current){current={...current,...result};}else current={...result,id:crypto.randomUUID(),data:null,versions:[],updated:Date.now()};
    dirty=true;$('build-prompt').value='';state();$('connection-status').textContent='Gadgeten är klar. Prova den och spara när du är nöjd.';
  }catch(problem){
    if(['bridge_session_expired','bridge_unavailable'].includes(problem.code)){connected=false;$('connect').hidden=false;$('connect').textContent='Anslut igen';$('disconnect').hidden=true;}
    error(problem.name==='AbortError'?'Uppdraget stoppades. Dina tidigare ändringar finns kvar.':problem.message);$('connection-status').textContent=connected?'Uppdraget avslutades':'Ingen agent ansluten';
  }
  finally{controller=null;$('stop').hidden=true;$('build').hidden=false;controls();library();}
};
$('setup-open').onclick=()=>$('setup').showModal();$('setup-close').onclick=()=>$('setup').close();
if(new URLSearchParams(location.search).get('connect')==='1')$('setup').showModal();
const local=['localhost','127.0.0.1'].includes(location.hostname);$('git-stage').hidden=!local;
$('git-stage').onclick=async()=>{
  if(!current||!confirm('Förbereda gadgetens kod för Git? Sparade data följer inte med. Koden blir tillgänglig på sajten när du accepterar ändringen och publicerar.'))return;
  try{const response=await fetch('/__editor/gadgets/stage',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:current.id,...validArtifact(current)})});const data=await response.json();if(!response.ok)throw Error(data.error||'Git-export kräver den fullständiga designverkstaden.');$('save-status').textContent='Förberedd för Git. Öppna designverkstadens Git-panel och granska ändringen.';}catch(problem){error(problem.message);}
};
window.addEventListener('beforeunload',event=>{if(dirty||controller){event.preventDefault();event.returnValue='';}});
if(['sp1e.se','www.sp1e.se'].includes(location.hostname))cloudStatus().then(controls).catch(()=>{cloudAvailable=false;controls();});
document.addEventListener('securitypolicyviolation',event=>{if(event.effectiveDirective==='frame-src')error('Gadgeten försökte öppna en annan sida. Navigation från förhandsvisningen är blockerad.');});
try{items=await allGadgets();library();const shared=new URLSearchParams(location.search).get('gadget');if(shared&&/^[0-9a-f-]{36}$/.test(shared)){const response=await fetch('/assets/gadgets/published/'+shared+'.json');if(!response.ok)throw Error('Den publicerade gadgeten kunde inte öppnas.');create(await response.json());}if(bridge.isPaired())await connect();}catch(problem){error(problem.message);}
controls();
