export const POLICY="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; font-src data:; media-src data:; connect-src 'none'; frame-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'";
export function sandboxHtml(html,channel){
  const document=new DOMParser().parseFromString(html,'text/html');
  document.querySelectorAll('base,meta[http-equiv],iframe,object,embed').forEach(el=>el.remove());
  const policy=document.createElement('meta');policy.httpEquiv='Content-Security-Policy';policy.content=POLICY;
  const viewport=document.createElement('meta');viewport.name='viewport';viewport.content='width=device-width,initial-scale=1';
  const boot=document.createElement('script');
  boot.textContent=`(()=>{const channel=${JSON.stringify(channel)};let pending=[];
    window.sp1eGadget=Object.freeze({load:()=>new Promise(resolve=>{pending.push(resolve);parent.postMessage({type:'sp1e-gadget-load',channel},'*')}),save:value=>parent.postMessage({type:'sp1e-gadget-save',channel,value},'*')});
    window.addEventListener('message',event=>{if(event.source===parent&&event.data?.type==='sp1e-gadget-state'&&event.data.channel===channel){const receive=pending;pending=[];receive.forEach(resolve=>resolve(event.data.value));}});
    window.addEventListener('error',()=>parent.postMessage({type:'sp1e-gadget-error',channel},'*'));
    document.addEventListener('securitypolicyviolation',event=>parent.postMessage({type:'sp1e-gadget-blocked',channel,directive:event.effectiveDirective},'*'));
  })();`;
  document.head.prepend(policy,viewport,boot);
  return '<!doctype html>'+document.documentElement.outerHTML;
}
export function validArtifact(value){
  if(!value||typeof value!=='object'||typeof value.html!=='string'||value.html.length<10||value.html.length>200000)throw Error('Gadgeten behöver HTML-kod på högst 200000 tecken.');
  return {title:String(value.title||'Namnlös gadget').slice(0,100),summary:String(value.summary||'').slice(0,500),html:value.html};
}
