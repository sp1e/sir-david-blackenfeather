let database;
export function openDatabase(){
  if(!database)database=new Promise((resolve,reject)=>{const request=indexedDB.open('sp1e-gadgets',1);request.onupgradeneeded=()=>request.result.createObjectStore('gadgets',{keyPath:'id'});request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(Error('Webbläsaren kunde inte öppna gadgetbiblioteket.'));});
  return database;
}
async function operation(mode,action){const db=await openDatabase();return new Promise((resolve,reject)=>{const tx=db.transaction('gadgets',mode);let value;const request=action(tx.objectStore('gadgets'));request.onsuccess=()=>{value=request.result};tx.oncomplete=()=>resolve(value);tx.onerror=()=>reject(Error('Gadgeten kunde inte sparas. Exportera den för att behålla en kopia.'));});}
export const allGadgets=()=>operation('readonly',store=>store.getAll());
export const saveGadget=value=>operation('readwrite',store=>store.put(value));
export const deleteGadget=id=>operation('readwrite',store=>store.delete(id));
