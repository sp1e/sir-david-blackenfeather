@echo off
python "%~dp0agent_daemon.py"
pause
